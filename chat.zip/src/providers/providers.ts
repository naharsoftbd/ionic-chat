
import { Items } from '../mocks/providers/items';

export {
    Items,
};
