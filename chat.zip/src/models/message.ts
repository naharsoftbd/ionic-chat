export class Message {
  from: string = '';
  to: string = '';
  content: string = '';
  time: Date;
}
